from django.conf.urls import url, include
from django.contrib import admin
from Store.views import home

# Alberto: django auth is configured to use "/accounts/" as path to their preconfigured app. We align with this.
# This saves time to reconfigure all the urls and ensure "robustness".
urlpatterns = [
    url(r'^$', home, name='home'),
    url(r'^admin/', admin.site.urls),
    url(r'^accounts/', include('Users.urls')),
    url(r'^store/', include('Store.urls')),
    url(r'^api/', include('api.urls')),
    url('', include('social.apps.django_app.urls', namespace='social'))
]