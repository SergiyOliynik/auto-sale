from django.conf.urls import url, include
from . import views

urlpatterns = [
    # Map the API list
    url(r'^$', views.api, name='api'),
    url(r'^v1/', include('api.v1.urls')),
]