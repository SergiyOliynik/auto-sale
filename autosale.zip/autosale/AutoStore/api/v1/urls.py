
from django.conf.urls import url, include
from . import views

urlpatterns = [
    # Map the API list

    # mapped to /v1
    url(r'^$', views.v1, name='v1'),

    # mapped to /v1/games
    url(r'^games/$', views.games, name='games'),

    # mapped to /v1/games/<game_id>
    url(r'^games/(?P<game_id>[0-9]+)/$', views.game, name='game'),

    # mapped to /v1/categories
    url(r'^categories/$', views.categories, name='categories'),

    # mapped to /v1/categories/<category_id>
    url(r'^categories/(?P<category_id>[0-9]+)/$', views.category, name='category'),
]